import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score

st.set_page_config(page_title="Starbucks Calories Predictor", page_icon="☕", layout="wide")

st.title("☕ Starbucks Calories Prediction")
st.write(
    "This student project explores Starbucks nutrition data and predicts the estimated "
    "calories of a drink using its beverage category, beverage name, and preparation type."
)

@st.cache_data
def load_data():
    data = pd.read_csv("starbucks.csv")
    # Remove accidental spaces from CSV column names.
    data.columns = data.columns.str.strip()
    data["Calories"] = pd.to_numeric(data["Calories"], errors="coerce")
    data = data.dropna(subset=["Calories", "Beverage_category", "Beverage", "Beverage_prep"]).copy()
    for col in ["Beverage_category", "Beverage", "Beverage_prep"]:
        data[col] = data[col].astype(str).str.strip()
    return data

df = load_data()

features = ["Beverage_category", "Beverage", "Beverage_prep"]
X = df[features]
y = df["Calories"]

preprocessor = ColumnTransformer(
    transformers=[
        ("categorical", OneHotEncoder(handle_unknown="ignore"), features)
    ]
)
model = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("regressor", RandomForestRegressor(n_estimators=200, random_state=42))
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
model.fit(X_train, y_train)
predictions = model.predict(X_test)
mae = mean_absolute_error(y_test, predictions)
try:
    r2 = r2_score(y_test, predictions)
except ValueError:
    r2 = float("nan")

tab1, tab2, tab3 = st.tabs(["📊 Explore Data", "🔮 Predict Calories", "ℹ️ About"])

with tab1:
    st.subheader("Dataset overview")
    c1, c2, c3 = st.columns(3)
    c1.metric("Total records", f"{len(df):,}")
    c2.metric("Drink categories", f"{df['Beverage_category'].nunique():,}")
    c3.metric("Average calories", f"{df['Calories'].mean():.1f}")

    st.subheader("Preview")
    st.dataframe(df.head(20), use_container_width=True)

    st.subheader("Average calories by beverage category")
    avg_calories = df.groupby("Beverage_category", as_index=False)["Calories"].mean()
    fig, ax = plt.subplots(figsize=(10, 5))
    sns.barplot(data=avg_calories, x="Calories", y="Beverage_category", ax=ax)
    ax.set_xlabel("Average calories")
    ax.set_ylabel("Beverage category")
    fig.tight_layout()
    st.pyplot(fig)
    plt.close(fig)

    st.subheader("Missing values")
    missing = df.isna().sum().rename("Missing values").to_frame()
    st.dataframe(missing, use_container_width=True)

with tab2:
    st.subheader("Estimate calories for a Starbucks drink")
    st.info(
        "Choose a drink from this dataset. The result is a model estimate, not official nutrition advice. "
        "This is a small educational dataset, so predictions may not be exact."
    )

    category_options = sorted(df["Beverage_category"].unique().tolist())
    category = st.selectbox("Beverage category", category_options)

    drinks_in_category = sorted(
        df.loc[df["Beverage_category"] == category, "Beverage"].unique().tolist()
    )
    beverage = st.selectbox("Beverage", drinks_in_category)

    preps = sorted(
        df.loc[
            (df["Beverage_category"] == category) & (df["Beverage"] == beverage),
            "Beverage_prep"
        ].unique().tolist()
    )
    prep = st.selectbox("Preparation / size", preps)

    if st.button("Predict calories", type="primary"):
        row = pd.DataFrame([{
            "Beverage_category": category,
            "Beverage": beverage,
            "Beverage_prep": prep
        }])
        estimated = max(0, float(model.predict(row)[0]))
        st.success(f"Estimated calories: **{estimated:.0f} kcal**")

        matching = df[
            (df["Beverage_category"] == category)
            & (df["Beverage"] == beverage)
            & (df["Beverage_prep"] == prep)
        ]
        if not matching.empty:
            actual = matching["Calories"].mean()
            st.caption(f"For comparison, the dataset's recorded average for this selection is {actual:.0f} kcal.")

    st.divider()
    st.subheader("Basic model evaluation")
    m1, m2 = st.columns(2)
    m1.metric("Mean Absolute Error (MAE)", f"{mae:.1f} calories")
    m2.metric("R² score", f"{r2:.3f}" if pd.notna(r2) else "Not available")
    st.caption(
        "Evaluation uses a random 80/20 train-test split. Because the dataset is small, "
        "these scores are only a classroom demonstration and do not guarantee performance on new drinks."
    )

with tab3:
    st.subheader("Project information")
    st.markdown("""
    **Problem:** Estimate the calories of a Starbucks drink.

    **Input features:**
    - Beverage category
    - Beverage name
    - Preparation / size

    **Target:** Calories

    **Algorithm:** Random Forest Regression with one-hot encoding for text categories.

    **Dataset:** `starbucks.csv` (242 records in the supplied file).

    **Important limitation:** This is a small dataset. The model learns patterns from the listed drinks and sizes; it may not predict a completely new drink reliably.
    """)
